#![no_std]

multiversx_sc::imports!();

mod invoice;
use invoice::Invoice;

const FEE_DENOMINATOR: u64 = 1_000u64;


#[multiversx_sc::contract]
pub trait InvoiceContract: multiversx_sc_modules::pause::PauseModule {
    #[init]
    fn init(&self, fee: u64, invoice_id: u64) {
        self.fee().set_if_empty(&fee);
        self.invoice_id().set_if_empty(&invoice_id);
    }

    #[endpoint(addInvoice)]
    fn add_invoice(&self, creator: ManagedAddress, token_id: EgldOrEsdtTokenIdentifier, nonce: u64, amount: BigUint) -> SCResult<u64> {
        let invoice_id = self.invoice_id().get();
        let invoice = Invoice {
            creator,
            token_identifier: token_id,
            nonce,
            amount,
        };
        self.invoices(invoice_id).set(&invoice);
        self.invoice_id().set(&invoice_id + 1);
        Ok(invoice_id)
    }

    #[endpoint(payInvoice)]
    #[payable("*")]
    fn pay_invoice(
        &self,
        invoice_id: u64,
        #[payment_token] token: EgldOrEsdtTokenIdentifier, 
        #[payment_nonce] nonce: u64,
        #[payment_amount] amount: BigUint
    ) {
        let invoice = self.invoices(invoice_id).get();
        require!(invoice.token_identifier == token, "wrong token");
        require!(invoice.nonce == nonce, "wrong nonce");
        require!(invoice.amount == amount, "wrong amount");
        let tax = amount.clone() * self.fee().get() / FEE_DENOMINATOR;
        if tax.clone() > 0u64 {
            self.pay_egld_esdt(token.clone(), nonce, self.blockchain().get_owner_address(), tax.clone());
        }
        let amount_without_tax = invoice.amount.clone() - tax.clone();
        self.pay_egld_esdt(token, nonce, invoice.creator.clone(), amount_without_tax);
        self.invoices(invoice_id).clear();
    }

    fn pay_egld_esdt(&self, token: EgldOrEsdtTokenIdentifier, nonce: u64, receiver: ManagedAddress, amount: BigUint) {
        if amount == 0u32 {
            return;
        }
        
        if token.is_egld() {
            self.send().direct_egld(&receiver, &amount);
        } else {
            self.send().direct_esdt(&receiver, &token.unwrap_esdt(), nonce, &amount);
        }
    }


    #[view(getFee)]
    #[storage_mapper("fee")]
    fn fee(&self) -> SingleValueMapper<u64>;


    #[view(getInvoiceId)]
    #[storage_mapper("invoice_id")]
    fn invoice_id(&self) -> SingleValueMapper<u64>;

    #[view(getInvoice)]
    #[storage_mapper("invoices")]
    fn invoices(&self, invoice_id: u64) -> SingleValueMapper<Invoice<Self::Api>>;
}
