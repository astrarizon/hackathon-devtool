multiversx_sc::derive_imports!();
multiversx_sc::imports!();

#[derive(NestedEncode, NestedDecode, TypeAbi, TopEncode, TopDecode, ManagedVecItem, Clone)]
pub struct Invoice<M: ManagedTypeApi> {
  pub creator: ManagedAddress<M>,
  pub token_identifier: EgldOrEsdtTokenIdentifier<M>,
  pub nonce: u64,
  pub amount: BigUint<M>,
}



